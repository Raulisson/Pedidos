<?php
// Redireciona para a URL
header("Location: index.php?controle=pedidos&acao=form");
exit();
?>
